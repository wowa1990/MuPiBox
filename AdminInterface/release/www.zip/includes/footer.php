
			<div id="footer">
				<div id="footerleft">
					<ul>
						<li><a href="https://mupibox.de/" target="_blank">MuPiBox.de</a></li>
						<li><a href="https://discord.gg/4EjCgpCbbe" target="_blank">Support on Discord</a></li>
						<li><a href="https://www.youtube.com/@mupibox" target="_blank">MuPiBox on Youtube</a></li>
					</ul>
				</div>
				<div id="footercenter">
					<ul>
						<li><a href="https://github.com/splitti/MuPiBox" target="_blank">Visit MupiBox on Github</a></li>
						<li><a href="https://github.com/splitti/MuPiBox/blob/main/LICENSE.md" target="_blank">License / Copyright</a></li>						
					</ul>
				</div>
				<div id="footerright">
					<img id="mupi" src="images/mupi.png" alt="I am Mupi and i like audiobooks..." title="I am Mupi and i like audiobooks...">
				</div>

			</div>
			<div id="lock-modal"></div>
			<div id="loading-circle"></div>
			<div id="mupif"><img src="images/mupif.png" /></div>
		</div>
		<img id="bottom" src="images/bottom.png" alt="">
<?php
	if( $change )
		{
		if( $change == 99 )
			{
			$CHANGE_TXT=$CHANGE_TXT."</ul></div>";
			}
		print '<div class="lightbox"><div class="iframeContainer"><div class="toolbarLB"><div class="closeLB" onclick="lightBoxClose()"><div class="closeLBSym">+</div></div></div><p>'.$CHANGE_TXT.'DONE</p></div></div>';
		} 
?>
<script>
    function updateFanIcon() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Empfangene Daten verarbeiten
                var fan_icon = this.responseText;
                
                // Batterie-Symbol in das Charger_Status-Div einfügen
                document.getElementById("Fan_Icon").innerHTML = fan_icon;
            }
        };
        xhttp.open("GET", "update_fanicon.php", true); // Passe den Pfad zur Serverseite an
        xhttp.send();
    }

	updateFanIcon();
    // Die Funktion alle 5 Sekunden aufrufen, um das Batteriesymbol zu aktualisieren
    setInterval(function() {
        updateFanIcon();
    }, 5000); // 5000 Millisekunden entsprechen 5 Sekunden




    // Funktion für die AJAX-Anfrage
    function updateWIFIIcon() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Empfangene Daten verarbeiten
                var bat_icon = this.responseText;
                
                // Batterie-Symbol in das Charger_Status-Div einfügen
                document.getElementById("Wifi_Icon").innerHTML = bat_icon;
            }
        };
        xhttp.open("GET", "update_wifiicon.php", true); // Passe den Pfad zur Serverseite an
        xhttp.send();
    }

	updateWIFIIcon();
    // Die Funktion alle 5 Sekunden aufrufen, um das Batteriesymbol zu aktualisieren
    setInterval(function() {
        updateWIFIIcon();
    }, 3000); // 5000 Millisekunden entsprechen 5 Sekunden


    // Funktion für die AJAX-Anfrage
    function updateBatteryIcon() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Empfangene Daten verarbeiten
                var bat_icon = this.responseText;
                
                // Batterie-Symbol in das Charger_Status-Div einfügen
                document.getElementById("Battery_Icon").innerHTML = bat_icon;
            }
        };
        xhttp.open("GET", "update_batteryicon.php", true); // Passe den Pfad zur Serverseite an
        xhttp.send();
    }

	updateBatteryIcon();
    // Die Funktion alle 5 Sekunden aufrufen, um das Batteriesymbol zu aktualisieren
    setInterval(function() {
        updateBatteryIcon();
    }, 5000); // 5000 Millisekunden entsprechen 5 Sekunden

$(document).ready(function() {
  $(document).on('click', '.show-title', function() {
    var title = $(this).attr('title');
    alert(title);
  });
});


//Code für offene Details
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("details").forEach(function (detail) {
        const id = detail.id;
        if (!id) return;

        // Zustand beim Laden setzen
        const isOpen = localStorage.getItem("details-" + id);
        if (isOpen === "true") {
            detail.open = true;
        } else if (isOpen === "false") {
            detail.open = false;
        }

        // Zustand speichern bei Änderung
        detail.addEventListener("toggle", function () {
            localStorage.setItem("details-" + id, detail.open);
        });
    });

    // Scrollposition wiederherstellen, die vor dem letzten Formular-Submit (z.B. ein
    // Dropdown mit onchange="this.form.submit()") gespeichert wurde - ohne das springt
    // die Seite nach jedem Submit an den Anfang zurück.
    const savedScroll = sessionStorage.getItem("mupibox-scroll");
    if (savedScroll !== null) {
        sessionStorage.removeItem("mupibox-scroll");
        const target = parseInt(savedScroll, 10);
        window.scrollTo(0, target);
        // Images, fonts and charts change the page height while loading: scroll again once everything is
        // there, then show the page (it is hidden by header.php until now).
        const reveal = function () {
            window.scrollTo(0, target);
            document.documentElement.style.visibility = "";
        };
        if (document.readyState === "complete") reveal();
        else window.addEventListener("load", reveal);
    }
});

document.addEventListener("submit", function () {
    sessionStorage.setItem("mupibox-scroll", window.scrollY);
});

// A real submit-button click fires the "submit" event above, but calling form.submit()
// from JS (e.g. a <select onchange="this.form.submit()">) does not - patch it directly
// so a dropdown reload also keeps the scroll position.
(function () {
    const nativeSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function () {
        sessionStorage.setItem("mupibox-scroll", window.scrollY);
        nativeSubmit.call(this);
    };
})();

</script>

	</body>
</html>

<?php
	// R3-B-5: previous code launched restart.sh / shutdown.sh in a
	// detached background shell with no inter-request locking — a
	// double-click on the reboot button (or two admin tabs both
	// pressing Reboot in quick succession) spawned two restart.sh
	// processes simultaneously. Their cleanup steps fight (kill of
	// pm2 from one terminates spawn from the other, etc.) and the
	// box can end up in a half-rebooted state. Wrap in `flock -n`
	// against a per-action lockfile so a second invocation while
	// the first is still running becomes a no-op.
	if( $reboot == 1 )
		{
		$command='( flock -n 9 || exit 0; sleep 5; sudo /usr/local/bin/mupibox/./restart.sh ) 9>/tmp/.mupibox.reboot.lock &';
		exec($command);
		}
	if( $shutdown == 1 )
		{
		$command='( flock -n 9 || exit 0; sleep 5; sudo /usr/local/bin/mupibox/./shutdown.sh ) 9>/tmp/.mupibox.shutdown.lock &';
		exec($command);
		}
?>
